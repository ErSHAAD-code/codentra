APP_NAME="Sample Project"
VERSION="1.0"
