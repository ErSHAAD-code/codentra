from utils import greet
from math_ops import add

print(greet("World"))
print("2+3=", add(2,3))
